//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: Versao_velCte_semINS_implementation_deploy_23a.h
//
// Code generated for Simulink model 'Versao_velCte_semINS_implementation_deploy_23a'.
//
// Model version                  : 1.15
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep 18 05:07:47 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM 64-bit (LP64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_h_
#define RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_h_
#include <math.h>
#include "rtwtypes.h"
#include "MW_SocketCAN.h"
#include "slros2_initialize.h"
#include "Versao_velCte_semINS_implementation_deploy_23a_types.h"

extern "C"
{

#include "rt_nonfinite.h"

}

extern "C"
{

#include "rtGetNaN.h"

}

#include <stddef.h>
#include "can_message.h"

// Macros for accessing real-time model data structure
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#define Versao_velCte_semINS_implementation_deploy_23a_M (Versao_velCte_semINS_impleme_M)

// Block signals (default storage)
struct B_Versao_velCte_semINS_implem_T {
  SL_Bus_geometry_msgs_PoseStamped In1;// '<S3>/In1'
  SL_Bus_geometry_msgs_PoseStamped b_varargout_2;
  char_T errString1[65];
  char_T errString1_m[65];
  char_T errString1_c[63];
  char_T errString1_k[63];
  char_T errString2[53];
  char_T errString2_c[53];
  char_T errString2_b[52];
  char_T errString2_p[52];
  linuxCANMsg CANReceive_o1;           // '<Root>/CAN Receive'
  CAN_MESSAGE_BUS CANPack1;            // '<Root>/CAN Pack1'
  CAN_MESSAGE_BUS CANPack;             // '<Root>/CAN Pack'
  real_T currPose[3];
  real_T VectorConcatenate[3];         // '<S7>/Vector Concatenate'
  real_T CANUnpack_o1;                 // '<Root>/CAN Unpack'
  real_T CANUnpack_o2;                 // '<Root>/CAN Unpack'
  real_T Gain;                         // '<Root>/Gain'
  real_T Constant;                     // '<S9>/Constant'
  real_T steerCmd;                     // '<S8>/Kinematic'
  real_T Hv_on;                        // '<S2>/Chart'
  real_T angleInRadians;
  real_T b;
  uint8_T rxData[8];
};

// Block states (default storage) for system '<Root>'
struct DW_Versao_velCte_semINS_imple_T {
  nvidiacoder_common_CANReceive_T obj; // '<Root>/CAN Receive1'
  nvidiacoder_common_CANReceive_T obj_l;// '<Root>/CAN Receive'
  nvidiacoder_common_CANTransmi_T obj_j;// '<Root>/CAN Transmit1'
  nvidiacoder_common_CANTransmi_T obj_n;// '<Root>/CAN Transmit'
  ros_slros2_internal_block_Sub_T obj_o;// '<S1>/SourceBlock'
  int_T CANUnpack_ModeSignalID;        // '<Root>/CAN Unpack'
  int_T CANUnpack_StatusPortID;        // '<Root>/CAN Unpack'
  int_T CANPack1_ModeSignalID;         // '<Root>/CAN Pack1'
  int_T CANPack_ModeSignalID;          // '<Root>/CAN Pack'
  uint8_T is_active_c2_Versao_velCte_semI;// '<S2>/Chart'
  uint8_T is_c2_Versao_velCte_semINS_impl;// '<S2>/Chart'
};

// Parameters (default storage)
struct P_Versao_velCte_semINS_implem_T_ {
  real_T stanley_kpfw;                 // Variable: stanley_kpfw
                                          //  Referenced by: '<S8>/Kinematic'

  real_T stanley_kprv;                 // Variable: stanley_kprv
                                          //  Referenced by: '<S8>/Kinematic'

  SL_Bus_geometry_msgs_PoseStamped Out1_Y0;// Computed Parameter: Out1_Y0
                                              //  Referenced by: '<S3>/Out1'

  SL_Bus_geometry_msgs_PoseStamped Constant_Value;// Computed Parameter: Constant_Value
                                                     //  Referenced by: '<S1>/Constant'

  bus_imu Constant1_Value;             // Computed Parameter: Constant1_Value
                                          //  Referenced by: '<Root>/Constant1'

  bus_route Constant2_Value;           // Computed Parameter: Constant2_Value
                                          //  Referenced by: '<Root>/Constant2'

  real_T CANReceive_SampleTime;        // Expression: 0.005
                                          //  Referenced by: '<Root>/CAN Receive'

  real_T CANReceive1_SampleTime;       // Expression: 0.05
                                          //  Referenced by: '<Root>/CAN Receive1'

  real_T Kinematic_MaxSteeringAngle;   // Expression: MaxSteeringAngle
                                          //  Referenced by: '<S8>/Kinematic'

  real_T Kinematic_Wheelbase;          // Expression: Wheelbase
                                          //  Referenced by: '<S8>/Kinematic'

  real_T Constant_Value_f;             // Expression: forward_moviment
                                          //  Referenced by: '<S5>/Constant'

  real_T Constant_Value_b;             // Expression: 1.0
                                          //  Referenced by: '<S9>/Constant'

  real_T Constant_Value_m;             // Expression: centro_cordenadas_carro
                                          //  Referenced by: '<Root>/Constant'

  real_T Constant3_Value;              // Expression: 1
                                          //  Referenced by: '<Root>/Constant3'

  real_T Gain_Gain;                    // Expression: curvatura_roda_para_coluna
                                          //  Referenced by: '<Root>/Gain'

};

// Real-time Model Data Structure
struct tag_RTM_Versao_velCte_semINS__T {
  const char_T * volatile errorStatus;

  //
  //  Timing:
  //  The following substructure contains information regarding
  //  the timing information for the model.

  struct {
    struct {
      uint8_T TID[2];
    } TaskCounters;
  } Timing;
};

extern CAN_DATATYPE CAN_DATATYPE_GROUND;

// Class declaration for model Versao_velCte_semINS_implementation_deploy_23a
class Versao_velCte_semINS_implementation_deploy_23a
{
  // public data and function members
 public:
  // Real-Time Model get method
  RT_MODEL_Versao_velCte_semINS_T * getRTM();

  // model initialize function
  void initialize();

  // model step function
  void step();

  // model terminate function
  void terminate();

  // Constructor
  Versao_velCte_semINS_implementation_deploy_23a();

  // Destructor
  ~Versao_velCte_semINS_implementation_deploy_23a();

  // private data and function members
 private:
  // Block signals
  B_Versao_velCte_semINS_implem_T Versao_velCte_semINS_implemen_B;

  // Block states
  DW_Versao_velCte_semINS_imple_T Versao_velCte_semINS_impleme_DW;

  // Tunable parameters
  static P_Versao_velCte_semINS_implem_T Versao_velCte_semINS_implemen_P;

  // private member function(s) for subsystem '<Root>'
  void Versao_angleUtilities_wrapTo2Pi(real_T *theta);
  void Versao_ve_SystemCore_setup_fjgr(ros_slros2_internal_block_Sub_T *obj);
  void Versao_velCte__SystemCore_setup(nvidiacoder_common_CANReceive_T *obj);
  void Versao_velC_SystemCore_setup_fj(nvidiacoder_common_CANTransmi_T *obj);

  // Real-Time Model
  RT_MODEL_Versao_velCte_semINS_T Versao_velCte_semINS_impleme_M;
};

extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

//-
//  These blocks were eliminated from the model due to optimizations:
//
//  Block '<Root>/CAN unpack inversor' : Unused code path elimination
//  Block '<Root>/Data Type Conversion1' : Unused code path elimination
//  Block '<S9>/Acelera��o lateral' : Unused code path elimination
//  Block '<S39>/Derivative Gain' : Unused code path elimination
//  Block '<S40>/Filter' : Unused code path elimination
//  Block '<S40>/SumD' : Unused code path elimination
//  Block '<S42>/Integral Gain' : Unused code path elimination
//  Block '<S45>/Integrator' : Unused code path elimination
//  Block '<S48>/Filter Coefficient' : Unused code path elimination
//  Block '<S50>/Proportional Gain' : Unused code path elimination
//  Block '<S54>/Sum' : Unused code path elimination
//  Block '<S9>/Product' : Unused code path elimination
//  Block '<S9>/Saturation' : Unused code path elimination
//  Block '<S9>/Sqrt' : Unused code path elimination
//  Block '<S9>/Sum1' : Unused code path elimination
//  Block '<S62>/Add' : Unused code path elimination
//  Block '<S62>/Constant' : Unused code path elimination
//  Block '<S62>/Divide' : Unused code path elimination
//  Block '<S62>/Product' : Unused code path elimination
//  Block '<S62>/Product1' : Unused code path elimination
//  Block '<S62>/Saturation' : Unused code path elimination
//  Block '<S62>/Square' : Unused code path elimination
//  Block '<S62>/Square1' : Unused code path elimination
//  Block '<S62>/Square2' : Unused code path elimination
//  Block '<S62>/Subtract' : Unused code path elimination
//  Block '<S62>/Unit Delay' : Unused code path elimination
//  Block '<S62>/Unit Delay1' : Unused code path elimination
//  Block '<S62>/Unit Delay2' : Unused code path elimination
//  Block '<S62>/Unit Delay3' : Unused code path elimination
//  Block '<Root>/rpm - m//s' : Unused code path elimination


//-
//  The generated code includes comments that allow you to trace directly
//  back to the appropriate location in the model.  The basic format
//  is <system>/block_name, where system is the system number (uniquely
//  assigned by Simulink) and block_name is the name of the block.
//
//  Use the MATLAB hilite_system command to trace the generated code back
//  to the model.  For example,
//
//  hilite_system('<S3>')    - opens system 3
//  hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
//
//  Here is the system hierarchy for this model
//
//  '<Root>' : 'Versao_velCte_semINS_implementation_deploy_23a'
//  '<S1>'   : 'Versao_velCte_semINS_implementation_deploy_23a/Subscribe2'
//  '<S2>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados'
//  '<S3>'   : 'Versao_velCte_semINS_implementation_deploy_23a/Subscribe2/Enabled Subsystem'
//  '<S4>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/Chart'
//  '<S5>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados'
//  '<S6>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal'
//  '<S7>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/organiza entradas'
//  '<S8>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/Lateral Controller Stanley'
//  '<S9>'   : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal'
//  '<S10>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/Lateral Controller Stanley/Dynamic'
//  '<S11>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/Lateral Controller Stanley/Kinematic'
//  '<S12>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/Lateral Controller Stanley/Dynamic/Dynamic Disabled'
//  '<S13>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller'
//  '<S14>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Anti-windup'
//  '<S15>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/D Gain'
//  '<S16>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Filter'
//  '<S17>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Filter ICs'
//  '<S18>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/I Gain'
//  '<S19>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Ideal P Gain'
//  '<S20>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Ideal P Gain Fdbk'
//  '<S21>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Integrator'
//  '<S22>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Integrator ICs'
//  '<S23>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/N Copy'
//  '<S24>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/N Gain'
//  '<S25>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/P Copy'
//  '<S26>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Parallel P Gain'
//  '<S27>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Reset Signal'
//  '<S28>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Saturation'
//  '<S29>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Saturation Fdbk'
//  '<S30>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Sum'
//  '<S31>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Sum Fdbk'
//  '<S32>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tracking Mode'
//  '<S33>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tracking Mode Sum'
//  '<S34>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tsamp - Integral'
//  '<S35>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tsamp - Ngain'
//  '<S36>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/postSat Signal'
//  '<S37>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/preSat Signal'
//  '<S38>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Anti-windup/Passthrough'
//  '<S39>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/D Gain/Internal Parameters'
//  '<S40>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Filter/Disc. Forward Euler Filter'
//  '<S41>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Filter ICs/Internal IC - Filter'
//  '<S42>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/I Gain/Internal Parameters'
//  '<S43>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Ideal P Gain/Passthrough'
//  '<S44>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Ideal P Gain Fdbk/Disabled'
//  '<S45>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Integrator/Discrete'
//  '<S46>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Integrator ICs/Internal IC'
//  '<S47>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/N Copy/Disabled'
//  '<S48>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/N Gain/Internal Parameters'
//  '<S49>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/P Copy/Disabled'
//  '<S50>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Parallel P Gain/Internal Parameters'
//  '<S51>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Reset Signal/Disabled'
//  '<S52>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Saturation/Passthrough'
//  '<S53>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Saturation Fdbk/Disabled'
//  '<S54>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Sum/Sum_PID'
//  '<S55>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Sum Fdbk/Disabled'
//  '<S56>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tracking Mode/Disabled'
//  '<S57>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tracking Mode Sum/Passthrough'
//  '<S58>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tsamp - Integral/TsSignalSpecification'
//  '<S59>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/Tsamp - Ngain/Passthrough'
//  '<S60>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/postSat Signal/Forward_Path'
//  '<S61>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/controlador_principal/calculo_velocidade_longitudinal/PID Controller/preSat Signal/Forward_Path'
//  '<S62>'  : 'Versao_velCte_semINS_implementation_deploy_23a/controle_maquina_estados/resposta_maquina_estados/organiza entradas/calculo curvatura'

#endif          // RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_h_

//
// File trailer for generated code.
//
// [EOF]
//
