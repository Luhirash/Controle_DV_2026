//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: Versao_velCte_semINS_implementation_deploy_23a_private.h
//
// Code generated for Simulink model 'Versao_velCte_semINS_implementation_deploy_23a'.
//
// Model version                  : 1.15
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep 18 05:07:47 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM 64-bit (LP64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_private_h_
#define RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_private_h_
#include "rtwtypes.h"
#include "Versao_velCte_semINS_implementation_deploy_23a_types.h"
#endif  // RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_private_h_

//
// File trailer for generated code.
//
// [EOF]
//
