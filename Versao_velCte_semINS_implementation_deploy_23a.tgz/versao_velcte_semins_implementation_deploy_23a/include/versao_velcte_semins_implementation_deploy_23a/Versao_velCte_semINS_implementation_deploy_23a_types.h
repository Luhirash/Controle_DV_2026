//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: Versao_velCte_semINS_implementation_deploy_23a_types.h
//
// Code generated for Simulink model 'Versao_velCte_semINS_implementation_deploy_23a'.
//
// Model version                  : 1.15
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep 18 05:07:47 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM 64-bit (LP64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#ifndef RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_types_h_
#define RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_types_h_
#include "rtwtypes.h"
#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_builtin_interfaces_Time_
#define DEFINED_TYPEDEF_FOR_SL_Bus_builtin_interfaces_Time_

// MsgType=builtin_interfaces/Time
struct SL_Bus_builtin_interfaces_Time
{
  int32_T sec;
  uint32_T nanosec;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_ROSVariableLengthArrayInfo_
#define DEFINED_TYPEDEF_FOR_SL_Bus_ROSVariableLengthArrayInfo_

struct SL_Bus_ROSVariableLengthArrayInfo
{
  uint32_T CurrentLength;
  uint32_T ReceivedLength;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_std_msgs_Header_
#define DEFINED_TYPEDEF_FOR_SL_Bus_std_msgs_Header_

// MsgType=std_msgs/Header
struct SL_Bus_std_msgs_Header
{
  // MsgType=builtin_interfaces/Time
  SL_Bus_builtin_interfaces_Time stamp;

  // PrimitiveROSType=string:IsVarLen=1:VarLenCategory=data:VarLenElem=frame_id_SL_Info:TruncateAction=warn 
  uint8_T frame_id[128];

  // IsVarLen=1:VarLenCategory=length:VarLenElem=frame_id
  SL_Bus_ROSVariableLengthArrayInfo frame_id_SL_Info;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Point_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Point_

// MsgType=geometry_msgs/Point
struct SL_Bus_geometry_msgs_Point
{
  real_T x;
  real_T y;
  real_T z;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Quaternion_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Quaternion_

// MsgType=geometry_msgs/Quaternion
struct SL_Bus_geometry_msgs_Quaternion
{
  real_T x;
  real_T y;
  real_T z;
  real_T w;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Pose_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_Pose_

// MsgType=geometry_msgs/Pose
struct SL_Bus_geometry_msgs_Pose
{
  // MsgType=geometry_msgs/Point
  SL_Bus_geometry_msgs_Point position;

  // MsgType=geometry_msgs/Quaternion
  SL_Bus_geometry_msgs_Quaternion orientation;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_PoseStamped_
#define DEFINED_TYPEDEF_FOR_SL_Bus_geometry_msgs_PoseStamped_

// MsgType=geometry_msgs/PoseStamped
struct SL_Bus_geometry_msgs_PoseStamped
{
  // MsgType=std_msgs/Header
  SL_Bus_std_msgs_Header header;

  // MsgType=geometry_msgs/Pose
  SL_Bus_geometry_msgs_Pose pose;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_bus_imu_
#define DEFINED_TYPEDEF_FOR_bus_imu_

struct bus_imu
{
  real_T pos_x;
  real_T pos_y;
  real_T pos_theta;
  real_T vel_x;
  real_T vel_y;
  real_T vel_yaw;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_bus_route_
#define DEFINED_TYPEDEF_FOR_bus_route_

struct bus_route
{
  real_T desired_x;
  real_T desired_y;
  real_T desired_yaw;
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_CAN_MESSAGE_BUS_
#define DEFINED_TYPEDEF_FOR_CAN_MESSAGE_BUS_

struct CAN_MESSAGE_BUS
{
  uint8_T Extended;
  uint8_T Length;
  uint8_T Remote;
  uint8_T Error;
  uint32_T ID;
  real_T Timestamp;
  uint8_T Data[8];
};

#endif

#ifndef DEFINED_TYPEDEF_FOR_linuxCANMsg_
#define DEFINED_TYPEDEF_FOR_linuxCANMsg_

struct linuxCANMsg
{
  uint8_T Extended;
  uint8_T Length;
  uint8_T Remote;
  uint8_T Error;
  uint32_T ID;
  real_T Timestamp;
  uint8_T Data[8];
};

#endif

#ifndef struct_nvidiacoder_common_CANReceive_T
#define struct_nvidiacoder_common_CANReceive_T

struct nvidiacoder_common_CANReceive_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  real_T SampleTime;
  int32_T sockHandleDataFrames;
  int32_T sockHandleErrorFrames;
  boolean_T Initialized;
};

#endif                                // struct_nvidiacoder_common_CANReceive_T

#ifndef struct_nvidiacoder_common_CANTransmi_T
#define struct_nvidiacoder_common_CANTransmi_T

struct nvidiacoder_common_CANTransmi_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
  int32_T sockHandleDataFrames;
  int32_T sockHandleErrorFrames;
  boolean_T notFirstStep;
  boolean_T Initialized;
};

#endif                                // struct_nvidiacoder_common_CANTransmi_T

// Custom Type definition for MATLABSystem: '<S1>/SourceBlock'
#include "rmw/qos_profiles.h"
#include "rmw/types.h"
#include "rmw/types.h"
#include "rmw/types.h"
#ifndef struct_ros_slros2_internal_block_Sub_T
#define struct_ros_slros2_internal_block_Sub_T

struct ros_slros2_internal_block_Sub_T
{
  boolean_T matlabCodegenIsDeleted;
  int32_T isInitialized;
  boolean_T isSetupComplete;
};

#endif                                // struct_ros_slros2_internal_block_Sub_T

// Parameters (default storage)
typedef struct P_Versao_velCte_semINS_implem_T_ P_Versao_velCte_semINS_implem_T;

// Forward declaration for rtModel
typedef struct tag_RTM_Versao_velCte_semINS__T RT_MODEL_Versao_velCte_semINS_T;

#endif    // RTW_HEADER_Versao_velCte_semINS_implementation_deploy_23a_types_h_

//
// File trailer for generated code.
//
// [EOF]
//
