/* MW_SocketCAN_raspi.c*/

#include "MW_SocketCAN.h"

#if !( defined(MATLAB_MEX_FILE) || defined(RSIM_PARAMETER_LOADING) ||  defined(RSIM_WITH_SL_SOLVER) )
// Code generation

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h> // For read/write data using Berkeley Sockets
#include <net/if.h> // For ifreq, ifname, etc
#include <linux/socket.h> // For PF_CAN Sockets
#include <linux/can.h> // For CAN structures
#include <linux/can/error.h> // CAN Error Handling
#include <linux/can/raw.h> // CAN Raw Sockets
#include <assert.h> // For asserting error
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>

void MW_loadCANModules(const uint8_T isRealCAN)
{
    FILE *pLoadModules;
    if(isRealCAN==1)
    {
        pLoadModules = popen("sudo modprobe can","r");
        close(pLoadModules);
        pLoadModules = popen("sudo modprobe can_raw","r");
        close(pLoadModules);
        pLoadModules = popen("sudo modprobe mttcan","r");
        close(pLoadModules);
    }
    else
    {
        pLoadModules = popen("sudo modprobe vcan","r");
        close(pLoadModules);
    }
    
}
#endif