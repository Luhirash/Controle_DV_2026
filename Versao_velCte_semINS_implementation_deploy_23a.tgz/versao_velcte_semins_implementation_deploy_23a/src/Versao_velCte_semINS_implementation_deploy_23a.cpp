//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: Versao_velCte_semINS_implementation_deploy_23a.cpp
//
// Code generated for Simulink model 'Versao_velCte_semINS_implementation_deploy_23a'.
//
// Model version                  : 1.15
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep 18 05:07:47 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM 64-bit (LP64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "Versao_velCte_semINS_implementation_deploy_23a.h"
#include "Versao_velCte_semINS_implementation_deploy_23a_types.h"
#include "rtwtypes.h"
#include <math.h>

extern "C"
{

#include "rt_nonfinite.h"

}

#include "rmw/qos_profiles.h"
#include "rmw/types.h"
#include <stddef.h>

// Named constants for Chart: '<S2>/Chart'
const uint8_T Versao_velCte_semINS_im_IN_Idle = 2U;
const uint8_T Versao_velCte_semINS_impl_IN_HV = 1U;
static void rate_scheduler(RT_MODEL_Versao_velCte_semINS_T *const
  Versao_velCte_semINS_impleme_M);

//
//         This function updates active task flag for each subrate.
//         The function is called at model base rate, hence the
//         generated code self-manages all its subrates.
//
static void rate_scheduler(RT_MODEL_Versao_velCte_semINS_T *const
  Versao_velCte_semINS_impleme_M)
{
  // Compute which subrates run during the next base time step.  Subrates
  //  are an integer multiple of the base rate counter.  Therefore, the subtask
  //  counter is reset when it reaches its limit (zero means run).

  (Versao_velCte_semINS_impleme_M->Timing.TaskCounters.TID[1])++;
  if ((Versao_velCte_semINS_impleme_M->Timing.TaskCounters.TID[1]) > 9) {// Sample time: [0.05s, 0.0s] 
    Versao_velCte_semINS_impleme_M->Timing.TaskCounters.TID[1] = 0;
  }
}

// Function for MATLAB Function: '<S8>/Kinematic'
void Versao_velCte_semINS_implementation_deploy_23a::
  Versao_angleUtilities_wrapTo2Pi(real_T *theta)
{
  real_T x;
  boolean_T positiveInput;
  positiveInput = (*theta > 0.0);
  x = *theta;
  if (rtIsNaN(*theta)) {
    *theta = (rtNaN);
  } else if (rtIsInf(*theta)) {
    *theta = (rtNaN);
  } else if (*theta == 0.0) {
    *theta = 0.0;
  } else {
    boolean_T rEQ0;
    *theta = fmod(*theta, 6.2831853071795862);
    rEQ0 = (*theta == 0.0);
    if (!rEQ0) {
      real_T q;
      q = fabs(x / 6.2831853071795862);
      rEQ0 = !(fabs(q - floor(q + 0.5)) > 2.2204460492503131E-16 * q);
    }

    if (rEQ0) {
      *theta = 0.0;
    } else if (x < 0.0) {
      *theta += 6.2831853071795862;
    }
  }

  *theta += static_cast<real_T>((*theta == 0.0) && positiveInput) *
    6.2831853071795862;
}

void Versao_velCte_semINS_implementation_deploy_23a::
  Versao_ve_SystemCore_setup_fjgr(ros_slros2_internal_block_Sub_T *obj)
{
  rmw_qos_durability_policy_t durability;
  rmw_qos_history_policy_t history;
  rmw_qos_profile_t qos_profile;
  rmw_qos_reliability_policy_t reliability;
  char_T b_zeroDelimTopic[13];
  static const char_T tmp[12] = { '/', 't', 'e', 's', 't', 'e', '/', 'r', 'o',
    'u', 't', 'e' };

  obj->isInitialized = 1;
  qos_profile = rmw_qos_profile_default;
  history = RMW_QOS_POLICY_HISTORY_KEEP_LAST;
  reliability = RMW_QOS_POLICY_RELIABILITY_RELIABLE;
  durability = RMW_QOS_POLICY_DURABILITY_VOLATILE;
  SET_QOS_VALUES(qos_profile, history, (size_t)10.0, durability, reliability);
  for (int32_T i = 0; i < 12; i++) {
    b_zeroDelimTopic[i] = tmp[i];
  }

  b_zeroDelimTopic[12] = '\x00';
  Sub_Versao_velCte_semINS_implementation_deploy_23a_11.createSubscriber
    (&b_zeroDelimTopic[0], qos_profile);
  obj->isSetupComplete = true;
}

void Versao_velCte_semINS_implementation_deploy_23a::
  Versao_velCte__SystemCore_setup(nvidiacoder_common_CANReceive_T *obj)
{
  int32_T isCANSetup;
  int32_T stat;
  char_T errString3[20];
  char_T canInterface[5];
  static const char_T tmp[19] = { ' ', 'i', 's', ' ', 'n', 'o', 't', ' ', 'u',
    'p', '.', ' ', 'S', 'e', 't', ' ', 'u', 'p', ' ' };

  static const char_T tmp_0[14] = { ' ', 'i', 's', ' ', 'n', 'o', 't', ' ', 's',
    'e', 't', ' ', 'u', 'p' };

  static const char_T tmp_1[46] = { ' ', 'd', 'o', 'e', 's', ' ', 'n', 'o', 't',
    ' ', 'e', 'x', 'i', 's', 't', '.', ' ', 'S', 'e', 'l', 'e', 'c', 't', ' ',
    'a', ' ', 'v', 'a', 'l', 'i', 'd', ' ', 'C', 'A', 'N', ' ', 'i', 'n', 't',
    'e', 'r', 'f', 'a', 'c', 'e', '.' };

  static const char_T tmp_2[34] = { ' ', 'b', 'e', 'f', 'o', 'r', 'e', ' ', 'l',
    'a', 'u', 'n', 'c', 'h', 'i', 'n', 'g', ' ', 't', 'h', 'e', ' ', 'a', 'p',
    'p', 'l', 'i', 'c', 'a', 't', 'i', 'o', 'n', '.' };

  obj->isSetupComplete = false;
  obj->isInitialized = 1;
  canInterface[0] = 'c';
  canInterface[1] = 'a';
  canInterface[2] = 'n';
  canInterface[3] = '0';
  canInterface[4] = '\x00';
  stat = -1;
  isCANSetup = MW_checkIFStatus(&canInterface[0]);
  if (isCANSetup == 0) {
    MW_createSocket(&canInterface[0], &obj->sockHandleDataFrames);
    stat = MW_createSocket(&canInterface[0], &obj->sockHandleErrorFrames);
  } else if (isCANSetup == 1) {
    Versao_velCte_semINS_implemen_B.errString1_k[0] = 'c';
    Versao_velCte_semINS_implemen_B.errString1_k[1] = 'a';
    Versao_velCte_semINS_implemen_B.errString1_k[2] = 'n';
    Versao_velCte_semINS_implemen_B.errString1_k[3] = '0';
    for (isCANSetup = 0; isCANSetup < 19; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString1_k[isCANSetup + 4] =
        tmp[isCANSetup];
    }

    Versao_velCte_semINS_implemen_B.errString1_k[23] = 'c';
    Versao_velCte_semINS_implemen_B.errString1_k[24] = 'a';
    Versao_velCte_semINS_implemen_B.errString1_k[25] = 'n';
    Versao_velCte_semINS_implemen_B.errString1_k[26] = '0';
    for (isCANSetup = 0; isCANSetup < 34; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString1_k[isCANSetup + 27] =
        tmp_2[isCANSetup];
    }

    Versao_velCte_semINS_implemen_B.errString1_k[61] = '\n';
    Versao_velCte_semINS_implemen_B.errString1_k[62] = '\x00';
    MW_printError(&Versao_velCte_semINS_implemen_B.errString1_k[0]);
  } else if (isCANSetup == 2) {
    Versao_velCte_semINS_implemen_B.errString2_p[0] = 'c';
    Versao_velCte_semINS_implemen_B.errString2_p[1] = 'a';
    Versao_velCte_semINS_implemen_B.errString2_p[2] = 'n';
    Versao_velCte_semINS_implemen_B.errString2_p[3] = '0';
    for (isCANSetup = 0; isCANSetup < 46; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString2_p[isCANSetup + 4] =
        tmp_1[isCANSetup];
    }

    Versao_velCte_semINS_implemen_B.errString2_p[50] = '\n';
    Versao_velCte_semINS_implemen_B.errString2_p[51] = '\x00';
    MW_printError(&Versao_velCte_semINS_implemen_B.errString2_p[0]);
  } else {
    errString3[0] = 'c';
    errString3[1] = 'a';
    errString3[2] = 'n';
    errString3[3] = '0';
    for (isCANSetup = 0; isCANSetup < 14; isCANSetup++) {
      errString3[isCANSetup + 4] = tmp_0[isCANSetup];
    }

    errString3[18] = '\n';
    errString3[19] = '\x00';
    MW_printError(&errString3[0]);
  }

  obj->Initialized = (stat == 0);
  obj->isSetupComplete = true;
}

void Versao_velCte_semINS_implementation_deploy_23a::
  Versao_velC_SystemCore_setup_fj(nvidiacoder_common_CANTransmi_T *obj)
{
  int32_T isCANSetup;
  int32_T stat1;
  int32_T stat2;
  char_T errString3[21];
  char_T canInterface[6];
  static const char_T tmp[5] = { 'v', 'c', 'a', 'n', '0' };

  static const char_T tmp_0[19] = { ' ', 'i', 's', ' ', 'n', 'o', 't', ' ', 'u',
    'p', '.', ' ', 'S', 'e', 't', ' ', 'u', 'p', ' ' };

  static const char_T tmp_1[14] = { ' ', 'i', 's', ' ', 'n', 'o', 't', ' ', 's',
    'e', 't', ' ', 'u', 'p' };

  static const char_T tmp_2[46] = { ' ', 'd', 'o', 'e', 's', ' ', 'n', 'o', 't',
    ' ', 'e', 'x', 'i', 's', 't', '.', ' ', 'S', 'e', 'l', 'e', 'c', 't', ' ',
    'a', ' ', 'v', 'a', 'l', 'i', 'd', ' ', 'C', 'A', 'N', ' ', 'i', 'n', 't',
    'e', 'r', 'f', 'a', 'c', 'e', '.' };

  static const char_T tmp_3[34] = { ' ', 'b', 'e', 'f', 'o', 'r', 'e', ' ', 'l',
    'a', 'u', 'n', 'c', 'h', 'i', 'n', 'g', ' ', 't', 'h', 'e', ' ', 'a', 'p',
    'p', 'l', 'i', 'c', 'a', 't', 'i', 'o', 'n', '.' };

  obj->isSetupComplete = false;
  obj->isInitialized = 1;
  for (isCANSetup = 0; isCANSetup < 5; isCANSetup++) {
    canInterface[isCANSetup] = tmp[isCANSetup];
  }

  canInterface[5] = '\x00';
  stat1 = -1;
  stat2 = -1;
  isCANSetup = MW_checkIFStatus(&canInterface[0]);
  if (isCANSetup == 0) {
    stat1 = MW_createSocket(&canInterface[0], &obj->sockHandleDataFrames);
    stat2 = MW_createSocket(&canInterface[0], &obj->sockHandleErrorFrames);
  } else if (isCANSetup == 1) {
    for (isCANSetup = 0; isCANSetup < 5; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString1_m[isCANSetup] = tmp[isCANSetup];
    }

    for (isCANSetup = 0; isCANSetup < 19; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString1_m[isCANSetup + 5] =
        tmp_0[isCANSetup];
    }

    for (isCANSetup = 0; isCANSetup < 5; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString1_m[isCANSetup + 24] =
        tmp[isCANSetup];
    }

    for (isCANSetup = 0; isCANSetup < 34; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString1_m[isCANSetup + 29] =
        tmp_3[isCANSetup];
    }

    Versao_velCte_semINS_implemen_B.errString1_m[63] = '\n';
    Versao_velCte_semINS_implemen_B.errString1_m[64] = '\x00';
    MW_printError(&Versao_velCte_semINS_implemen_B.errString1_m[0]);
  } else if (isCANSetup == 2) {
    for (isCANSetup = 0; isCANSetup < 5; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString2_c[isCANSetup] = tmp[isCANSetup];
    }

    for (isCANSetup = 0; isCANSetup < 46; isCANSetup++) {
      Versao_velCte_semINS_implemen_B.errString2_c[isCANSetup + 5] =
        tmp_2[isCANSetup];
    }

    Versao_velCte_semINS_implemen_B.errString2_c[51] = '\n';
    Versao_velCte_semINS_implemen_B.errString2_c[52] = '\x00';
    MW_printError(&Versao_velCte_semINS_implemen_B.errString2_c[0]);
  } else {
    for (isCANSetup = 0; isCANSetup < 5; isCANSetup++) {
      errString3[isCANSetup] = tmp[isCANSetup];
    }

    for (isCANSetup = 0; isCANSetup < 14; isCANSetup++) {
      errString3[isCANSetup + 5] = tmp_1[isCANSetup];
    }

    errString3[19] = '\n';
    errString3[20] = '\x00';
    MW_printError(&errString3[0]);
  }

  if ((stat1 == 0) && (stat2 == 0)) {
    obj->Initialized = true;
  } else {
    obj->Initialized = false;
  }

  obj->isSetupComplete = true;
}

// Model step function
void Versao_velCte_semINS_implementation_deploy_23a::step()
{
  real_T d_idx_0;
  real_T d_idx_1;
  int32_T b_i;
  int32_T sockStatus;
  uint32_T rxid;
  char_T rxInterface_0[6];
  char_T rxInterface[5];
  uint8_T dataLength;
  uint8_T error;
  uint8_T extended;
  uint8_T remote;
  uint8_T status;
  boolean_T b_varargout_1;
  static const char_T tmp[5] = { 'v', 'c', 'a', 'n', '0' };

  // MATLABSystem: '<S1>/SourceBlock'
  b_varargout_1 =
    Sub_Versao_velCte_semINS_implementation_deploy_23a_11.getLatestMessage
    (&Versao_velCte_semINS_implemen_B.b_varargout_2);

  // Outputs for Enabled SubSystem: '<S1>/Enabled Subsystem' incorporates:
  //   EnablePort: '<S3>/Enable'

  if (b_varargout_1) {
    // SignalConversion generated from: '<S3>/In1'
    Versao_velCte_semINS_implemen_B.In1 =
      Versao_velCte_semINS_implemen_B.b_varargout_2;
  }

  // End of MATLABSystem: '<S1>/SourceBlock'
  // End of Outputs for SubSystem: '<S1>/Enabled Subsystem'

  // MATLABSystem: '<Root>/CAN Receive'
  if (Versao_velCte_semINS_impleme_DW.obj_l.SampleTime !=
      Versao_velCte_semINS_implemen_P.CANReceive_SampleTime) {
    Versao_velCte_semINS_impleme_DW.obj_l.SampleTime =
      Versao_velCte_semINS_implemen_P.CANReceive_SampleTime;
  }

  if (Versao_velCte_semINS_impleme_DW.obj_l.Initialized) {
    rxInterface[0] = 'c';
    rxInterface[1] = 'a';
    rxInterface[2] = 'n';
    rxInterface[3] = '0';
    rxInterface[4] = '\x00';
    sockStatus = MW_CAN_receiveCANMsg(&rxInterface[0],
      &Versao_velCte_semINS_implemen_B.CANReceive_o1.ID,
      &Versao_velCte_semINS_implemen_B.rxData[0],
      &Versao_velCte_semINS_implemen_B.CANReceive_o1.Length, &status,
      &Versao_velCte_semINS_implemen_B.CANReceive_o1.Extended, &remote,
      &Versao_velCte_semINS_implemen_B.CANReceive_o1.Error,
      Versao_velCte_semINS_impleme_DW.obj_l.sockHandleDataFrames,
      Versao_velCte_semINS_impleme_DW.obj_l.sockHandleErrorFrames);
    Versao_velCte_semINS_implemen_B.CANReceive_o1.Remote = (remote == 0);
    if (sockStatus != 0) {
      Versao_velCte_semINS_impleme_DW.obj_l.Initialized = false;
    }

    Versao_velCte_semINS_implemen_B.CANReceive_o1.Timestamp = 0.0;
    for (sockStatus = 0; sockStatus < 8; sockStatus++) {
      Versao_velCte_semINS_implemen_B.CANReceive_o1.Data[sockStatus] =
        Versao_velCte_semINS_implemen_B.rxData[sockStatus];
    }
  } else {
    Versao_velCte_semINS_implemen_B.CANReceive_o1.Extended = 0U;
    Versao_velCte_semINS_implemen_B.CANReceive_o1.Length = 0U;
    Versao_velCte_semINS_implemen_B.CANReceive_o1.Remote = 0U;
    Versao_velCte_semINS_implemen_B.CANReceive_o1.Error = 0U;
    Versao_velCte_semINS_implemen_B.CANReceive_o1.ID = 0U;
    Versao_velCte_semINS_implemen_B.CANReceive_o1.Timestamp = 0.0;
    for (sockStatus = 0; sockStatus < 8; sockStatus++) {
      Versao_velCte_semINS_implemen_B.CANReceive_o1.Data[sockStatus] = 0U;
    }
  }

  // End of MATLABSystem: '<Root>/CAN Receive'

  // S-Function (scanunpack): '<Root>/CAN Unpack'
  {
    // S-Function (scanunpack): '<Root>/CAN Unpack'
    if ((4 == Versao_velCte_semINS_implemen_B.CANReceive_o1.Length) &&
        (Versao_velCte_semINS_implemen_B.CANReceive_o1.ID != INVALID_CAN_ID) ) {
      if ((419369088 == Versao_velCte_semINS_implemen_B.CANReceive_o1.ID) && (1U
           == Versao_velCte_semINS_implemen_B.CANReceive_o1.Extended) ) {
        {
          // --------------- START Unpacking signal 0 ------------------
          //   startBit                = 0
          //   length                  = 2
          //   desiredSignalByteLayout = LITTLEENDIAN
          //   dataType                = SIGNED
          //   factor                  = 1.0
          //   offset                  = 0.0
          //  -----------------------------------------------------------------------
          {
            real_T outValue = 0;

            {
              int8_T unpackedValue = 0;

              {
                uint8_T tempValue = (uint8_T) (0);
                int8_T* tempValuePtr = (int8_T*)&tempValue;

                {
                  tempValue = tempValue | (uint8_T)((uint8_T)
                    (Versao_velCte_semINS_implemen_B.CANReceive_o1.Data[0]) &
                    (uint8_T)(0x3U));
                }

                unpackedValue = *tempValuePtr;
              }

              {
                uint8_T* tempRawValuePtr = (uint8_T*)&unpackedValue;
                uint8_T tempValue = *tempRawValuePtr;
                int8_T* tempValuePtr = (int8_T*)&tempValue;
                uint8_T bitValue = tempValue & (uint8_T)0x2U;
                if (bitValue != 0U) {
                  // Extend sign bits
                  tempValue = tempValue | (uint8_T)0xFCU;
                  unpackedValue = *tempValuePtr;
                }
              }

              outValue = (real_T) (unpackedValue);
            }

            {
              real_T result = (real_T) outValue;
              Versao_velCte_semINS_implemen_B.CANUnpack_o1 = result;
            }
          }

          // --------------- START Unpacking signal 1 ------------------
          //   startBit                = 3
          //   length                  = 8
          //   desiredSignalByteLayout = LITTLEENDIAN
          //   dataType                = SIGNED
          //   factor                  = 1.0
          //   offset                  = 0.0
          //  -----------------------------------------------------------------------
          {
            real_T outValue = 0;

            {
              int8_T unpackedValue = 0;

              {
                uint8_T tempValue = (uint8_T) (0);
                int8_T* tempValuePtr = (int8_T*)&tempValue;

                {
                  tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                    (Versao_velCte_semINS_implemen_B.CANReceive_o1.Data[0]) &
                    (uint8_T)(0xF8U)) >> 3);
                  tempValue = tempValue | (uint8_T)((uint8_T)((uint8_T)
                    (Versao_velCte_semINS_implemen_B.CANReceive_o1.Data[1]) &
                    (uint8_T)(0x7U)) << 5);
                }

                unpackedValue = *tempValuePtr;
              }

              outValue = (real_T) (unpackedValue);
            }

            {
              real_T result = (real_T) outValue;
              Versao_velCte_semINS_implemen_B.CANUnpack_o2 = result;
            }
          }
        }
      }
    }
  }

  // Chart: '<S2>/Chart'
  if (Versao_velCte_semINS_impleme_DW.is_active_c2_Versao_velCte_semI == 0U) {
    Versao_velCte_semINS_impleme_DW.is_active_c2_Versao_velCte_semI = 1U;
    Versao_velCte_semINS_impleme_DW.is_c2_Versao_velCte_semINS_impl =
      Versao_velCte_semINS_im_IN_Idle;
  } else if (Versao_velCte_semINS_impleme_DW.is_c2_Versao_velCte_semINS_impl ==
             Versao_velCte_semINS_impl_IN_HV) {
    Versao_velCte_semINS_implemen_B.Hv_on = 1.0;
    if ((Versao_velCte_semINS_implemen_B.CANUnpack_o1 == 0.0) ||
        (Versao_velCte_semINS_implemen_B.CANUnpack_o2 == 1.0)) {
      Versao_velCte_semINS_impleme_DW.is_c2_Versao_velCte_semINS_impl =
        Versao_velCte_semINS_im_IN_Idle;
    }

    // case IN_Idle:
  } else if (Versao_velCte_semINS_implemen_B.CANUnpack_o1 == 1.0) {
    Versao_velCte_semINS_impleme_DW.is_c2_Versao_velCte_semINS_impl =
      Versao_velCte_semINS_impl_IN_HV;
    Versao_velCte_semINS_implemen_B.Hv_on = 1.0;
  }

  // End of Chart: '<S2>/Chart'

  // Outputs for Enabled SubSystem: '<S2>/resposta_maquina_estados' incorporates:
  //   EnablePort: '<S5>/Enable'

  if (Versao_velCte_semINS_implemen_B.Hv_on > 0.0) {
    // SignalConversion generated from: '<S7>/Vector Concatenate' incorporates:
    //   BusAssignment: '<Root>/Bus Assignment1'

    Versao_velCte_semINS_implemen_B.VectorConcatenate[0] =
      Versao_velCte_semINS_implemen_B.In1.pose.position.x;

    // SignalConversion generated from: '<S7>/Vector Concatenate' incorporates:
    //   BusAssignment: '<Root>/Bus Assignment1'

    Versao_velCte_semINS_implemen_B.VectorConcatenate[1] =
      Versao_velCte_semINS_implemen_B.In1.pose.position.y;

    // MATLAB Function: '<S8>/Kinematic' incorporates:
    //   BusAssignment: '<Root>/Bus Assignment1'
    //   Concatenate: '<S5>/Vector Concatenate1'
    //   Constant: '<Root>/Constant'
    //   Constant: '<Root>/Constant2'
    //   Constant: '<Root>/Constant3'
    //   Constant: '<S5>/Constant'

    Versao_velCte_semINS_implemen_B.currPose[0] =
      Versao_velCte_semINS_implemen_P.Constant_Value_m;
    Versao_velCte_semINS_implemen_B.currPose[1] =
      Versao_velCte_semINS_implemen_P.Constant_Value_m;
    Versao_velCte_semINS_implemen_B.VectorConcatenate[2] = 0.017453292519943295 *
      Versao_velCte_semINS_implemen_P.Constant2_Value.desired_yaw;
    Versao_angleUtilities_wrapTo2Pi
      (&Versao_velCte_semINS_implemen_B.VectorConcatenate[2]);
    Versao_velCte_semINS_implemen_B.currPose[2] = 0.017453292519943295 *
      Versao_velCte_semINS_implemen_P.Constant_Value_m;
    Versao_angleUtilities_wrapTo2Pi(&Versao_velCte_semINS_implemen_B.currPose[2]);
    if (Versao_velCte_semINS_implemen_P.Constant_Value_f == 1.0) {
      Versao_velCte_semINS_implemen_B.currPose[0] =
        Versao_velCte_semINS_implemen_P.Kinematic_Wheelbase * cos
        (Versao_velCte_semINS_implemen_B.currPose[2]) +
        Versao_velCte_semINS_implemen_P.Constant_Value_m;
      Versao_velCte_semINS_implemen_B.currPose[1] =
        Versao_velCte_semINS_implemen_P.Kinematic_Wheelbase * sin
        (Versao_velCte_semINS_implemen_B.currPose[2]) +
        Versao_velCte_semINS_implemen_P.Constant_Value_m;
      d_idx_0 = Versao_velCte_semINS_implemen_B.currPose[0] -
        Versao_velCte_semINS_implemen_B.VectorConcatenate[0];
      d_idx_1 = Versao_velCte_semINS_implemen_B.currPose[1] -
        Versao_velCte_semINS_implemen_B.VectorConcatenate[1];
    } else {
      d_idx_0 = Versao_velCte_semINS_implemen_B.currPose[0] -
        Versao_velCte_semINS_implemen_B.VectorConcatenate[0];
      d_idx_1 = Versao_velCte_semINS_implemen_B.currPose[1] -
        Versao_velCte_semINS_implemen_B.VectorConcatenate[1];
    }

    Versao_velCte_semINS_implemen_B.b =
      (Versao_velCte_semINS_implemen_B.currPose[2] -
       Versao_velCte_semINS_implemen_B.VectorConcatenate[2]) +
      3.1415926535897931;
    Versao_angleUtilities_wrapTo2Pi(&Versao_velCte_semINS_implemen_B.b);
    if (Versao_velCte_semINS_implemen_P.Constant_Value_f == 1.0) {
      if (Versao_velCte_semINS_implemen_P.Constant_Value_f == 1.0) {
        Versao_velCte_semINS_implemen_B.angleInRadians =
          Versao_velCte_semINS_implemen_P.stanley_kpfw;
      } else {
        Versao_velCte_semINS_implemen_B.angleInRadians =
          Versao_velCte_semINS_implemen_P.stanley_kprv;
      }

      Versao_velCte_semINS_implemen_B.angleInRadians = -(atan(-(d_idx_0 * sin
        (Versao_velCte_semINS_implemen_B.VectorConcatenate[2]) - cos
        (Versao_velCte_semINS_implemen_B.VectorConcatenate[2]) * d_idx_1) *
        Versao_velCte_semINS_implemen_B.angleInRadians /
        (Versao_velCte_semINS_implemen_P.Constant3_Value + 1.0)) +
        (Versao_velCte_semINS_implemen_B.b - 3.1415926535897931));
    } else {
      if (Versao_velCte_semINS_implemen_P.Constant_Value_f == 1.0) {
        Versao_velCte_semINS_implemen_B.angleInRadians =
          Versao_velCte_semINS_implemen_P.stanley_kpfw;
      } else {
        Versao_velCte_semINS_implemen_B.angleInRadians =
          Versao_velCte_semINS_implemen_P.stanley_kprv;
      }

      Versao_velCte_semINS_implemen_B.angleInRadians = atan(-(d_idx_0 * sin
        (Versao_velCte_semINS_implemen_B.VectorConcatenate[2]) - cos
        (Versao_velCte_semINS_implemen_B.VectorConcatenate[2]) * d_idx_1) *
        Versao_velCte_semINS_implemen_B.angleInRadians /
        (Versao_velCte_semINS_implemen_P.Constant3_Value - 1.0)) +
        (Versao_velCte_semINS_implemen_B.b - 3.1415926535897931);
    }

    Versao_velCte_semINS_implemen_B.steerCmd = 57.295779513082323 *
      Versao_velCte_semINS_implemen_B.angleInRadians;
    d_idx_0 = fabs(Versao_velCte_semINS_implemen_B.steerCmd);
    if (rtIsNaN(Versao_velCte_semINS_implemen_B.steerCmd)) {
      Versao_velCte_semINS_implemen_B.angleInRadians = (rtNaN);
    } else if (Versao_velCte_semINS_implemen_B.steerCmd < 0.0) {
      Versao_velCte_semINS_implemen_B.angleInRadians = -1.0;
    } else {
      Versao_velCte_semINS_implemen_B.angleInRadians =
        (Versao_velCte_semINS_implemen_B.steerCmd > 0.0);
    }

    if ((!(d_idx_0 <= Versao_velCte_semINS_implemen_P.Kinematic_MaxSteeringAngle))
        && (!rtIsNaN(Versao_velCte_semINS_implemen_P.Kinematic_MaxSteeringAngle)))
    {
      d_idx_0 = Versao_velCte_semINS_implemen_P.Kinematic_MaxSteeringAngle;
    }

    Versao_velCte_semINS_implemen_B.steerCmd =
      Versao_velCte_semINS_implemen_B.angleInRadians * d_idx_0;

    // End of MATLAB Function: '<S8>/Kinematic'

    // Constant: '<S9>/Constant'
    Versao_velCte_semINS_implemen_B.Constant =
      Versao_velCte_semINS_implemen_P.Constant_Value_b;
  }

  // End of Outputs for SubSystem: '<S2>/resposta_maquina_estados'

  // S-Function (scanpack): '<Root>/CAN Pack1'
  // S-Function (scanpack): '<Root>/CAN Pack1'
  Versao_velCte_semINS_implemen_B.CANPack1.ID = 13U;
  Versao_velCte_semINS_implemen_B.CANPack1.Length = 1U;
  Versao_velCte_semINS_implemen_B.CANPack1.Extended = 1U;
  Versao_velCte_semINS_implemen_B.CANPack1.Remote = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[0] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[1] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[2] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[3] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[4] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[5] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[6] = 0;
  Versao_velCte_semINS_implemen_B.CANPack1.Data[7] = 0;

  {
    // --------------- START Packing signal 0 ------------------
    //   startBit                = 0
    //   length                  = 8
    //   desiredSignalByteLayout = LITTLEENDIAN
    //   dataType                = UNSIGNED
    //   factor                  = 1.0
    //   offset                  = 0.0
    //   minimum                 = 0.0
    //   maximum                 = 0.0
    //  -----------------------------------------------------------------------
    {
      real_T outValue = 0;

      {
        real_T result = Versao_velCte_semINS_implemen_B.Constant;

        // no scaling required
        // round to closest integer value for integer CAN signal
        outValue = round(result);
      }

      {
        uint8_T packedValue;
        if (outValue > (real_T)(255)) {
          packedValue = (uint8_T) 255;
        } else if (outValue < (real_T)(0)) {
          packedValue = (uint8_T) 0;
        } else {
          packedValue = (uint8_T) (outValue);
        }

        {
          {
            Versao_velCte_semINS_implemen_B.CANPack1.Data[0] =
              Versao_velCte_semINS_implemen_B.CANPack1.Data[0] | (uint8_T)
              (packedValue);
          }
        }
      }
    }
  }

  // MATLABSystem: '<Root>/CAN Transmit'
  if (Versao_velCte_semINS_impleme_DW.obj_n.Initialized) {
    for (sockStatus = 0; sockStatus < 8; sockStatus++) {
      Versao_velCte_semINS_implemen_B.rxData[sockStatus] = 0U;
    }

    for (sockStatus = 0; sockStatus < 5; sockStatus++) {
      rxInterface_0[sockStatus] = tmp[sockStatus];
    }

    rxInterface_0[5] = '\x00';
    if (Versao_velCte_semINS_implemen_B.CANPack1.Remote == 0) {
      sockStatus = Versao_velCte_semINS_implemen_B.CANPack1.Length - 1;
      for (b_i = 0; b_i <= sockStatus; b_i++) {
        Versao_velCte_semINS_implemen_B.rxData[static_cast<uint8_T>(static_cast<
          uint32_T>(b_i) + 1U) - 1] =
          Versao_velCte_semINS_implemen_B.CANPack1.Data[static_cast<uint8_T>(
          static_cast<uint32_T>(b_i) + 1U) - 1];
      }
    }

    sockStatus = MW_CAN_transmitCANMsg(&rxInterface_0[0], static_cast<uint8_T>
      (Versao_velCte_semINS_implemen_B.CANPack1.Extended == 0),
      Versao_velCte_semINS_implemen_B.CANPack1.ID,
      Versao_velCte_semINS_implemen_B.CANPack1.Length,
      &Versao_velCte_semINS_implemen_B.rxData[0],
      Versao_velCte_semINS_implemen_B.CANPack1.Remote, &status, 0, 1.0,
      Versao_velCte_semINS_impleme_DW.obj_n.sockHandleDataFrames,
      Versao_velCte_semINS_impleme_DW.obj_n.sockHandleErrorFrames, static_cast<
      uint8_T>(Versao_velCte_semINS_impleme_DW.obj_n.notFirstStep));
    if (sockStatus != 0) {
      Versao_velCte_semINS_impleme_DW.obj_n.Initialized = false;
    }
  }

  // End of MATLABSystem: '<Root>/CAN Transmit'

  // Gain: '<Root>/Gain'
  Versao_velCte_semINS_implemen_B.Gain =
    Versao_velCte_semINS_implemen_P.Gain_Gain *
    Versao_velCte_semINS_implemen_B.steerCmd;

  // S-Function (scanpack): '<Root>/CAN Pack'
  // S-Function (scanpack): '<Root>/CAN Pack'
  Versao_velCte_semINS_implemen_B.CANPack.ID = 1025U;
  Versao_velCte_semINS_implemen_B.CANPack.Length = 4U;
  Versao_velCte_semINS_implemen_B.CANPack.Extended = 0U;
  Versao_velCte_semINS_implemen_B.CANPack.Remote = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[0] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[1] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[2] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[3] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[4] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[5] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[6] = 0;
  Versao_velCte_semINS_implemen_B.CANPack.Data[7] = 0;

  {
    // --------------- START Packing signal 0 ------------------
    //   startBit                = 24
    //   length                  = 32
    //   desiredSignalByteLayout = BIGENDIAN
    //   dataType                = SIGNED
    //   factor                  = 10000.0
    //   offset                  = 0.0
    //   minimum                 = 0.0
    //   maximum                 = 0.0
    //  -----------------------------------------------------------------------
    {
      real_T outValue = 0;

      {
        real_T result = Versao_velCte_semINS_implemen_B.Gain;

        // no offset to apply
        result = result * (1 / 10000.0);

        // round to closest integer value for integer CAN signal
        outValue = round(result);
      }

      {
        int32_T packedValue;
        int32_T scaledValue;
        if (outValue > 2147483647.0) {
          scaledValue = 2147483647;
        } else if (outValue < -2147483648.0) {
          scaledValue = -2147483647 - 1;
        } else {
          scaledValue = (int32_T) outValue;
        }

        packedValue = (int32_T) (scaledValue);

        {
          uint32_T* tempValuePtr = (uint32_T*)&packedValue;
          uint32_T tempValue = *tempValuePtr;

          {
            Versao_velCte_semINS_implemen_B.CANPack.Data[3] =
              Versao_velCte_semINS_implemen_B.CANPack.Data[3] | (uint8_T)
              ((uint32_T)(tempValue & (uint32_T)0xFFU));
            Versao_velCte_semINS_implemen_B.CANPack.Data[2] =
              Versao_velCte_semINS_implemen_B.CANPack.Data[2] | (uint8_T)
              ((uint32_T)((uint32_T)(tempValue & (uint32_T)0xFF00U) >> 8));
            Versao_velCte_semINS_implemen_B.CANPack.Data[1] =
              Versao_velCte_semINS_implemen_B.CANPack.Data[1] | (uint8_T)
              ((uint32_T)((uint32_T)(tempValue & (uint32_T)0xFF0000U) >> 16));
            Versao_velCte_semINS_implemen_B.CANPack.Data[0] =
              Versao_velCte_semINS_implemen_B.CANPack.Data[0] | (uint8_T)
              ((uint32_T)((uint32_T)(tempValue & (uint32_T)0xFF000000U) >> 24));
          }
        }
      }
    }
  }

  // MATLABSystem: '<Root>/CAN Transmit1'
  if (Versao_velCte_semINS_impleme_DW.obj_j.Initialized) {
    for (sockStatus = 0; sockStatus < 8; sockStatus++) {
      Versao_velCte_semINS_implemen_B.rxData[sockStatus] = 0U;
    }

    for (sockStatus = 0; sockStatus < 5; sockStatus++) {
      rxInterface_0[sockStatus] = tmp[sockStatus];
    }

    rxInterface_0[5] = '\x00';
    if (Versao_velCte_semINS_implemen_B.CANPack.Remote == 0) {
      sockStatus = Versao_velCte_semINS_implemen_B.CANPack.Length - 1;
      for (b_i = 0; b_i <= sockStatus; b_i++) {
        Versao_velCte_semINS_implemen_B.rxData[static_cast<uint8_T>
          (static_cast<uint32_T>(b_i) + 1U) - 1] =
          Versao_velCte_semINS_implemen_B.CANPack.Data[static_cast<uint8_T>(
          static_cast<uint32_T>(b_i) + 1U) - 1];
      }
    }

    sockStatus = MW_CAN_transmitCANMsg(&rxInterface_0[0], static_cast<uint8_T>
      (Versao_velCte_semINS_implemen_B.CANPack.Extended == 0),
      Versao_velCte_semINS_implemen_B.CANPack.ID,
      Versao_velCte_semINS_implemen_B.CANPack.Length,
      &Versao_velCte_semINS_implemen_B.rxData[0],
      Versao_velCte_semINS_implemen_B.CANPack.Remote, &status, 0, 1.0,
      Versao_velCte_semINS_impleme_DW.obj_j.sockHandleDataFrames,
      Versao_velCte_semINS_impleme_DW.obj_j.sockHandleErrorFrames, static_cast<
      uint8_T>(Versao_velCte_semINS_impleme_DW.obj_j.notFirstStep));
    if (sockStatus != 0) {
      Versao_velCte_semINS_impleme_DW.obj_j.Initialized = false;
    }
  }

  // End of MATLABSystem: '<Root>/CAN Transmit1'
  if ((&Versao_velCte_semINS_impleme_M)->Timing.TaskCounters.TID[1] == 0) {
    // MATLABSystem: '<Root>/CAN Receive1'
    if (Versao_velCte_semINS_impleme_DW.obj.SampleTime !=
        Versao_velCte_semINS_implemen_P.CANReceive1_SampleTime) {
      Versao_velCte_semINS_impleme_DW.obj.SampleTime =
        Versao_velCte_semINS_implemen_P.CANReceive1_SampleTime;
    }

    if (Versao_velCte_semINS_impleme_DW.obj.Initialized) {
      rxInterface[0] = 'c';
      rxInterface[1] = 'a';
      rxInterface[2] = 'n';
      rxInterface[3] = '0';
      rxInterface[4] = '\x00';
      sockStatus = MW_CAN_receiveCANMsg(&rxInterface[0], &rxid,
        &Versao_velCte_semINS_implemen_B.rxData[0], &dataLength, &status,
        &extended, &remote, &error,
        Versao_velCte_semINS_impleme_DW.obj.sockHandleDataFrames,
        Versao_velCte_semINS_impleme_DW.obj.sockHandleErrorFrames);
      if (sockStatus != 0) {
        Versao_velCte_semINS_impleme_DW.obj.Initialized = false;
      }
    }

    // End of MATLABSystem: '<Root>/CAN Receive1'
  }

  rate_scheduler((&Versao_velCte_semINS_impleme_M));
}

// Model initialize function
void Versao_velCte_semINS_implementation_deploy_23a::initialize()
{
  // Registration code

  // initialize non-finites
  rt_InitInfAndNaN(sizeof(real_T));

  // Start for MATLABSystem: '<S1>/SourceBlock'
  Versao_ve_SystemCore_setup_fjgr(&Versao_velCte_semINS_impleme_DW.obj_o);

  // Start for MATLABSystem: '<Root>/CAN Receive'
  Versao_velCte_semINS_impleme_DW.obj_l.sockHandleDataFrames = 0;
  Versao_velCte_semINS_impleme_DW.obj_l.sockHandleErrorFrames = 0;
  Versao_velCte_semINS_impleme_DW.obj_l.isInitialized = 0;
  Versao_velCte_semINS_impleme_DW.obj_l.matlabCodegenIsDeleted = false;
  Versao_velCte_semINS_impleme_DW.obj_l.SampleTime =
    Versao_velCte_semINS_implemen_P.CANReceive_SampleTime;
  Versao_velCte__SystemCore_setup(&Versao_velCte_semINS_impleme_DW.obj_l);

  // Start for S-Function (scanunpack): '<Root>/CAN Unpack'

  //-----------S-Function Block: <Root>/CAN Unpack -----------------

  // Start for Enabled SubSystem: '<S2>/resposta_maquina_estados'
  // Start for Constant: '<S9>/Constant'
  Versao_velCte_semINS_implemen_B.Constant =
    Versao_velCte_semINS_implemen_P.Constant_Value_b;

  // End of Start for SubSystem: '<S2>/resposta_maquina_estados'
  // Start for MATLABSystem: '<Root>/CAN Transmit'
  Versao_velC_SystemCore_setup_fj(&Versao_velCte_semINS_impleme_DW.obj_n);

  // Start for MATLABSystem: '<Root>/CAN Transmit1'
  Versao_velC_SystemCore_setup_fj(&Versao_velCte_semINS_impleme_DW.obj_j);

  // Start for MATLABSystem: '<Root>/CAN Receive1'
  Versao_velCte_semINS_impleme_DW.obj.sockHandleDataFrames = 0;
  Versao_velCte_semINS_impleme_DW.obj.sockHandleErrorFrames = 0;
  Versao_velCte_semINS_impleme_DW.obj.isInitialized = 0;
  Versao_velCte_semINS_impleme_DW.obj.matlabCodegenIsDeleted = false;
  Versao_velCte_semINS_impleme_DW.obj.SampleTime =
    Versao_velCte_semINS_implemen_P.CANReceive1_SampleTime;
  Versao_velCte__SystemCore_setup(&Versao_velCte_semINS_impleme_DW.obj);

  // SystemInitialize for Enabled SubSystem: '<S1>/Enabled Subsystem'
  // SystemInitialize for SignalConversion generated from: '<S3>/In1' incorporates:
  //   Outport: '<S3>/Out1'

  Versao_velCte_semINS_implemen_B.In1 = Versao_velCte_semINS_implemen_P.Out1_Y0;

  // End of SystemInitialize for SubSystem: '<S1>/Enabled Subsystem'
}

// Model terminate function
void Versao_velCte_semINS_implementation_deploy_23a::terminate()
{
  char_T canInterface_0[6];
  char_T canInterface[5];
  static const char_T tmp[5] = { 'v', 'c', 'a', 'n', '0' };

  // Terminate for MATLABSystem: '<S1>/SourceBlock'
  if (!Versao_velCte_semINS_impleme_DW.obj_o.matlabCodegenIsDeleted) {
    Versao_velCte_semINS_impleme_DW.obj_o.matlabCodegenIsDeleted = true;
  }

  // End of Terminate for MATLABSystem: '<S1>/SourceBlock'

  // Terminate for MATLABSystem: '<Root>/CAN Receive'
  if (!Versao_velCte_semINS_impleme_DW.obj_l.matlabCodegenIsDeleted) {
    Versao_velCte_semINS_impleme_DW.obj_l.matlabCodegenIsDeleted = true;
    if ((Versao_velCte_semINS_impleme_DW.obj_l.isInitialized == 1) &&
        Versao_velCte_semINS_impleme_DW.obj_l.isSetupComplete &&
        Versao_velCte_semINS_impleme_DW.obj_l.Initialized) {
      canInterface[0] = 'c';
      canInterface[1] = 'a';
      canInterface[2] = 'n';
      canInterface[3] = '0';
      canInterface[4] = '\x00';
      MW_clearSocket(&Versao_velCte_semINS_impleme_DW.obj_l.sockHandleDataFrames,
                     &canInterface[0]);
      MW_clearSocket
        (&Versao_velCte_semINS_impleme_DW.obj_l.sockHandleErrorFrames,
         &canInterface[0]);
    }
  }

  // End of Terminate for MATLABSystem: '<Root>/CAN Receive'

  // Terminate for MATLABSystem: '<Root>/CAN Transmit'
  if (!Versao_velCte_semINS_impleme_DW.obj_n.matlabCodegenIsDeleted) {
    Versao_velCte_semINS_impleme_DW.obj_n.matlabCodegenIsDeleted = true;
    if ((Versao_velCte_semINS_impleme_DW.obj_n.isInitialized == 1) &&
        Versao_velCte_semINS_impleme_DW.obj_n.isSetupComplete &&
        Versao_velCte_semINS_impleme_DW.obj_n.Initialized) {
      for (int32_T i = 0; i < 5; i++) {
        canInterface_0[i] = tmp[i];
      }

      canInterface_0[5] = '\x00';
      MW_clearSocket(&Versao_velCte_semINS_impleme_DW.obj_n.sockHandleDataFrames,
                     &canInterface_0[0]);
      MW_clearSocket
        (&Versao_velCte_semINS_impleme_DW.obj_n.sockHandleErrorFrames,
         &canInterface_0[0]);
    }
  }

  // End of Terminate for MATLABSystem: '<Root>/CAN Transmit'

  // Terminate for MATLABSystem: '<Root>/CAN Transmit1'
  if (!Versao_velCte_semINS_impleme_DW.obj_j.matlabCodegenIsDeleted) {
    Versao_velCte_semINS_impleme_DW.obj_j.matlabCodegenIsDeleted = true;
    if ((Versao_velCte_semINS_impleme_DW.obj_j.isInitialized == 1) &&
        Versao_velCte_semINS_impleme_DW.obj_j.isSetupComplete &&
        Versao_velCte_semINS_impleme_DW.obj_j.Initialized) {
      for (int32_T i = 0; i < 5; i++) {
        canInterface_0[i] = tmp[i];
      }

      canInterface_0[5] = '\x00';
      MW_clearSocket(&Versao_velCte_semINS_impleme_DW.obj_j.sockHandleDataFrames,
                     &canInterface_0[0]);
      MW_clearSocket
        (&Versao_velCte_semINS_impleme_DW.obj_j.sockHandleErrorFrames,
         &canInterface_0[0]);
    }
  }

  // End of Terminate for MATLABSystem: '<Root>/CAN Transmit1'

  // Terminate for MATLABSystem: '<Root>/CAN Receive1'
  if (!Versao_velCte_semINS_impleme_DW.obj.matlabCodegenIsDeleted) {
    Versao_velCte_semINS_impleme_DW.obj.matlabCodegenIsDeleted = true;
    if ((Versao_velCte_semINS_impleme_DW.obj.isInitialized == 1) &&
        Versao_velCte_semINS_impleme_DW.obj.isSetupComplete &&
        Versao_velCte_semINS_impleme_DW.obj.Initialized) {
      canInterface[0] = 'c';
      canInterface[1] = 'a';
      canInterface[2] = 'n';
      canInterface[3] = '0';
      canInterface[4] = '\x00';
      MW_clearSocket(&Versao_velCte_semINS_impleme_DW.obj.sockHandleDataFrames,
                     &canInterface[0]);
      MW_clearSocket(&Versao_velCte_semINS_impleme_DW.obj.sockHandleErrorFrames,
                     &canInterface[0]);
    }
  }

  // End of Terminate for MATLABSystem: '<Root>/CAN Receive1'
}

// Constructor
Versao_velCte_semINS_implementation_deploy_23a::
  Versao_velCte_semINS_implementation_deploy_23a() :
  Versao_velCte_semINS_implemen_B(),
  Versao_velCte_semINS_impleme_DW(),
  Versao_velCte_semINS_impleme_M()
{
  // Currently there is no constructor body generated.
}

// Destructor
Versao_velCte_semINS_implementation_deploy_23a::
  ~Versao_velCte_semINS_implementation_deploy_23a()
{
  // Currently there is no destructor body generated.
}

// Real-Time Model get method
RT_MODEL_Versao_velCte_semINS_T * Versao_velCte_semINS_implementation_deploy_23a::
  getRTM()
{
  return (&Versao_velCte_semINS_impleme_M);
}

//
// File trailer for generated code.
//
// [EOF]
//
