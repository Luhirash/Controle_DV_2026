//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
//
// File: Versao_velCte_semINS_implementation_deploy_23a_data.cpp
//
// Code generated for Simulink model 'Versao_velCte_semINS_implementation_deploy_23a'.
//
// Model version                  : 1.15
// Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
// C/C++ source code generated on : Fri Sep 18 05:07:47 2026
//
// Target selection: ert.tlc
// Embedded hardware selection: ARM Compatible->ARM 64-bit (LP64)
// Code generation objectives: Unspecified
// Validation result: Not run
//
#include "Versao_velCte_semINS_implementation_deploy_23a.h"

// Block parameters (default storage)
P_Versao_velCte_semINS_implem_T Versao_velCte_semINS_implementation_deploy_23a::
  Versao_velCte_semINS_implemen_P = {
  // Variable: stanley_kpfw
  //  Referenced by: '<S8>/Kinematic'

  5.0,

  // Variable: stanley_kprv
  //  Referenced by: '<S8>/Kinematic'

  5.0,

  // Computed Parameter: Out1_Y0
  //  Referenced by: '<S3>/Out1'

  {
    {
      {
        0,                             // sec
        0U                             // nanosec
      },                               // stamp

      {
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U }
      ,                                // frame_id

      {
        0U,                            // CurrentLength
        0U                             // ReceivedLength
      }                                // frame_id_SL_Info
    },                                 // header

    {
      {
        0.0,                           // x
        0.0,                           // y
        0.0                            // z
      },                               // position

      {
        0.0,                           // x
        0.0,                           // y
        0.0,                           // z
        0.0                            // w
      }                                // orientation
    }                                  // pose
  },

  // Computed Parameter: Constant_Value
  //  Referenced by: '<S1>/Constant'

  {
    {
      {
        0,                             // sec
        0U                             // nanosec
      },                               // stamp

      {
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U,
        0U, 0U }
      ,                                // frame_id

      {
        0U,                            // CurrentLength
        0U                             // ReceivedLength
      }                                // frame_id_SL_Info
    },                                 // header

    {
      {
        0.0,                           // x
        0.0,                           // y
        0.0                            // z
      },                               // position

      {
        0.0,                           // x
        0.0,                           // y
        0.0,                           // z
        0.0                            // w
      }                                // orientation
    }                                  // pose
  },

  // Computed Parameter: Constant1_Value
  //  Referenced by: '<Root>/Constant1'

  {
    0.0,                               // pos_x
    0.0,                               // pos_y
    0.0,                               // pos_theta
    0.0,                               // vel_x
    0.0,                               // vel_y
    0.0                                // vel_yaw
  },

  // Computed Parameter: Constant2_Value
  //  Referenced by: '<Root>/Constant2'

  {
    0.0,                               // desired_x
    0.0,                               // desired_y
    0.0                                // desired_yaw
  },

  // Expression: 0.005
  //  Referenced by: '<Root>/CAN Receive'

  0.005,

  // Expression: 0.05
  //  Referenced by: '<Root>/CAN Receive1'

  0.05,

  // Expression: MaxSteeringAngle
  //  Referenced by: '<S8>/Kinematic'

  36.0,

  // Expression: Wheelbase
  //  Referenced by: '<S8>/Kinematic'

  1.6,

  // Expression: forward_moviment
  //  Referenced by: '<S5>/Constant'

  1.0,

  // Expression: 1.0
  //  Referenced by: '<S9>/Constant'

  1.0,

  // Expression: centro_cordenadas_carro
  //  Referenced by: '<Root>/Constant'

  0.0,

  // Expression: 1
  //  Referenced by: '<Root>/Constant3'

  1.0,

  // Expression: curvatura_roda_para_coluna
  //  Referenced by: '<Root>/Gain'

  3.055
};

//
// File trailer for generated code.
//
// [EOF]
//
