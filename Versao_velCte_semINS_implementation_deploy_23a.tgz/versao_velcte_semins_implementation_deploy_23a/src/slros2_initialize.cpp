// Copyright 2022 The MathWorks, Inc.
// Generated 18-Sep-2026 05:07:51
#include "slros2_initialize.h"
// Versao_velCte_semINS_implementation_deploy_23a/Subscribe2
SimulinkSubscriber<geometry_msgs::msg::PoseStamped,SL_Bus_geometry_msgs_PoseStamped> Sub_Versao_velCte_semINS_implementation_deploy_23a_11;
